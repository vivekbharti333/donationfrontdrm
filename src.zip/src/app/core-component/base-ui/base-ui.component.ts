import { Component } from '@angular/core';

@Component({
  selector: 'app-base-ui',
  templateUrl: './base-ui.component.html',
  styleUrl: './base-ui.component.scss'
})
export class BaseUiComponent {

}
