import { Component } from '@angular/core';

@Component({
  selector: 'app-ui-offcanvas',
  templateUrl: './ui-offcanvas.component.html',
  styleUrl: './ui-offcanvas.component.scss'
})
export class UiOffcanvasComponent {

}
