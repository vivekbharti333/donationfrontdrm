import { Component } from '@angular/core';

@Component({
  selector: 'app-advanced-ui',
  templateUrl: './advanced-ui.component.html',
  styleUrl: './advanced-ui.component.scss'
})
export class AdvancedUiComponent {

}
