import { Component } from '@angular/core';

@Component({
  selector: 'app-currency-master',
  templateUrl: './currency-master.component.html',
  styleUrl: './currency-master.component.scss'
})
export class CurrencyMasterComponent {

}
