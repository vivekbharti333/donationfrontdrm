import { Component } from '@angular/core';

@Component({
  selector: 'app-currency-management',
  templateUrl: './currency-management.component.html',
  styleUrl: './currency-management.component.scss'
})
export class CurrencyManagementComponent {

}
