import { Component } from '@angular/core';

@Component({
  selector: 'app-donation-management',
  templateUrl: './donation-management.component.html',
  styleUrl: './donation-management.component.scss'
})
export class DonationManagementComponent {

}
