import { Component } from '@angular/core';

@Component({
  selector: 'app-categories-management',
  templateUrl: './categories-management.component.html',
  styleUrl: './categories-management.component.scss'
})
export class CategoriesManagementComponent {

}
